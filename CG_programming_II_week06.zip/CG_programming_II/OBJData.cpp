#include "Init.h"
#include <iostream>

namespace OBJLoader 
{

	struct OBJData
	{
		GLfloat *vertices = nullptr;
		GLfloat *normals = nullptr;
		GLfloat *UVs = nullptr;
	//	GLint *faces = nullptr;
	 


	};

}